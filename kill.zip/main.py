from files.logging.log import *
from files.networking.handler import binder
log("main", "Starting C2...")
binder()